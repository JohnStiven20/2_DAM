package pizzeria.Modelo.Classes.Productos;

import java.util.List;

import pizzeria.Modelo.Classes.Ingredientes.Ingredientes;
import pizzeria.Modelo.enums.SizeApp;

public class Pizza extends Producto {

    private SizeApp size;
    private List<Ingredientes> ingredientes; 

    public Pizza(String nombre, double precio, SizeApp size , List<Ingredientes> ingredientes) {
        super(nombre, precio);
        this.size = size;
        this.ingredientes =  ingredientes; 
    }

    public SizeApp getSize() {
        return size;
    }

    public void setSize(SizeApp size) {
        this.size = size;
    }

    @Override
    public String toString() {
        return "Pizza [id=" + id + ", size=" + size + ", nombre=" + nombre + ", precio=" + precio + "]";
    }

}
