package pizzeria;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import pizzeria.Controller.ContraladorCliente;
import pizzeria.Controller.ContraladorPedido;
import pizzeria.Modelo.Classes.Ingredientes.Ingredientes;
import pizzeria.Modelo.Classes.Pagar.PagarEfectivo;
import pizzeria.Modelo.Classes.Productos.Bebida;
import pizzeria.Modelo.Classes.Productos.Pasta;
import pizzeria.Modelo.Classes.Productos.Pizza;
import pizzeria.Modelo.enums.SizeApp;

public class main2 {

    public static void main(String[] args) {

        ContraladorCliente controladorCliente = new ContraladorCliente();
        ContraladorPedido controladorpedido = new ContraladorPedido(null);

        controladorCliente.registrarCliente(14, "12345678A", "Juan Pérez", "Calle Falsa 123", "123456789",
                "juan@example.com", "passwordSeguro123");

        System.out.println("-------------------------------------------------------");
        System.out.println("Logincliente");
        controladorCliente.loginCliente("12345678A", "juan@example.com");

        System.out.println("-------------------------------------------------------");
        System.out.println("Registra linea pedido");

        controladorCliente.agragarLineaPedido(2, new Pizza("Pizza", 10, SizeApp.GRANDE, new ArrayList<>(
                Arrays.asList(
                        new Ingredientes("Tomates", new ArrayList<>(
                                Arrays.asList("Nitrigeno")))

                ))));
        controladorCliente.agragarLineaPedido(5, new Pizza("Pizza", 10, SizeApp.GRANDE, new ArrayList<>(
                Arrays.asList(
                        new Ingredientes("Tomates", new ArrayList<>(
                                Arrays.asList("Nitrigeno")))

                ))));

        controladorCliente.agragarLineaPedido(5, new Pizza("Pizza lustro", 3, SizeApp.GRANDE, new ArrayList<>(
                Arrays.asList(
                        new Ingredientes("Tomates", new ArrayList<>(
                                Arrays.asList("Nitrigeno")))

                ))));
        controladorCliente.agragarLineaPedido(2, new Bebida("Cocacola", 4, SizeApp.GRANDE));

        controladorCliente.agragarLineaPedido(4, new Pasta("Pasta", 3, new ArrayList<>(
                Arrays.asList(
                        new Ingredientes("Harina", new ArrayList<>(
                                Arrays.asList("Gluten"))),
                        new Ingredientes("Salsa de tomate", new ArrayList<>(
                                Arrays.asList("Tomate", "Albahaca"))),
                        new Ingredientes("Queso parmesano", new ArrayList<>(
                                Arrays.asList("Leche")))))));

        System.out.println("-------------------------------------------------------");
        System.out.println("Lista de productos en el pedido");
        controladorpedido.getPedidoActual().getListaLineaPedidos().forEach(x -> System.out.println(x));

        System.out.println("-------------------------------------------------------");
        System.out.println("Finalizar Pedido etapas");

        controladorpedido.cancelarPedido();
        controladorpedido.finalizadoPedido(new PagarEfectivo());
        controladorpedido.entregarPedido();


    }
}
