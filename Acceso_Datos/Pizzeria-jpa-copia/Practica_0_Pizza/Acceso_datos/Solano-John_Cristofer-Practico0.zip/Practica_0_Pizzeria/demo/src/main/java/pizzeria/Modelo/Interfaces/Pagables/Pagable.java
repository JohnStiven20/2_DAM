package pizzeria.Modelo.Interfaces.Pagables;

  public interface Pagable {
    

  public  void pagar(Float cantidad); 
  


    
}
