package pizzeria.Modelo.Classes.Productos;

import java.util.List;

import pizzeria.Modelo.Classes.Ingredientes.Ingredientes;

public class Pasta extends Producto {

    private List<Ingredientes> ingredientes;

    public Pasta(String nombre, double precio, List<Ingredientes> ingredientes) {
        super(nombre, precio);
        this.ingredientes = ingredientes;
    }

    @Override
    public String toString() {
        return "Pasta [id=" + id + ", nombre=" + nombre + ", precio=" + precio + ", ingredientes=" + ingredientes + "]";
    }

}
