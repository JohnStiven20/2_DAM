package pizzeria.Modelo.Classes.Pagar;

import pizzeria.Modelo.Interfaces.Pagables.Pagable;

public class PagarEfectivo  implements Pagable{

    @Override
    public void pagar(Float cantidad) {
             
    }

    
}
