
// package pizzeria;
// import main.java.pizzeria.Controller.ContraladorCliente;
// import main.java.pizzeria.Controller.ContraladorPedido;

// public class Main{

//     ContraladorCliente contraladorcliente = new ContraladorCliente();
//     ContraladorPedido contraladorpedido = new ContraladorPedido();

//     public static void main(String[] args) {

//         // List<LineaPedido> productos = new ArrayList<>();

//         // Pedido pedido = new Pedido(1, new Date(), 12f, EstadoPedido.PENDIENTE, productos);

//         // System.out.println("Pedido creado con éxito: " + pedido);

//         System.out.println("hola buenas");
//     }
// }
