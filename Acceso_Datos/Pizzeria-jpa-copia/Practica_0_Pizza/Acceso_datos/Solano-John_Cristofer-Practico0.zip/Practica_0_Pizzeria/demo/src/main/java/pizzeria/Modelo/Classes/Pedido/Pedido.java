package pizzeria.Modelo.Classes.Pedido;
import java.util.Date;
import java.util.List;

import pizzeria.Modelo.Classes.LineaPedido.LineaPedido;
import pizzeria.Modelo.enums.EstadoPedido;

public class Pedido {
    
   private int id ; 
   private Date fecha ; 
   private  float precioTotal;
   private EstadoPedido estado ; 
   private List<LineaPedido> listaLineaPedidos ; 
    static  int contador = 0; 

public Pedido( Date fecha, float precioTotal , EstadoPedido estado,  List<LineaPedido> listaLineaPedidos ) {
    this.id = this.contador++ ;
    this.fecha = fecha;
    this.precioTotal = precioTotal;
    this.estado = estado; 
    this.listaLineaPedidos = listaLineaPedidos ; 
}

  public  boolean AñadirLineaPedido(LineaPedido lineaPedido){     
      this.listaLineaPedidos.add(lineaPedido); 
      return true ; 
  } 

   public float totalPrecio(){    
           for (LineaPedido lineaPedido : listaLineaPedidos) {
             this.precioTotal +=  (float)   (lineaPedido.getCantidad() *  lineaPedido.getProducto().getPrecio()  );
           }
       return  this.precioTotal  ;    
   }


public int getId() {
    return id;
}

public void setId(int id) {
    this.id = id;
}

public Date getFecha() {
    return fecha;
}

public void setFecha(Date fecha) {
    this.fecha = fecha;
}

public float getPrecioTotal() {
    return precioTotal;
}

public void setPrecioTotal(float precioTotal) {
    this.precioTotal = precioTotal;
}

public EstadoPedido getEstado() {
    return estado;
}


public void setEstado(EstadoPedido estado) {
    this.estado = estado;
}


public List<LineaPedido> getListaLineaPedidos() {
    return listaLineaPedidos;
}


public void setListaLineaPedidos(List<LineaPedido> listaLineaPedidos) {
    this.listaLineaPedidos = listaLineaPedidos;
} 



   

}
