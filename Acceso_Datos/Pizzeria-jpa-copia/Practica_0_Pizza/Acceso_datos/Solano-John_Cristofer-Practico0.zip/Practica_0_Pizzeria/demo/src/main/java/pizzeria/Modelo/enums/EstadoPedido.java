package pizzeria.Modelo.enums;

public enum EstadoPedido {
    ENTREGADO,
    PENDIENTE,
    CANCELADO
}
