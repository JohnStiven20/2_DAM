package pizzeria.Modelo.enums;

public enum SizeApp {

    PEQUENO,
    GRANDE

}
