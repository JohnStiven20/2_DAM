package pizzeria.Modelo;

public enum SizeApp {
    PEQUENO,
    GRANDE
}
