package pizzeria.Modelo;

public enum EstadoPedido {
    ENTREGADO,
    PENDIENTE,
    CANCELADO
}
