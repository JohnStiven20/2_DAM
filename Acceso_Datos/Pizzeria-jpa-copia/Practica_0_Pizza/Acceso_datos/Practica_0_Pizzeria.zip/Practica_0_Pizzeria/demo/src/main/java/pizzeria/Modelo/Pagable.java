package pizzeria.Modelo;

  public interface Pagable {
    

  public  void pagar(Float cantidad); 
  


    
}
