package pizzeria.Modelo;


public class PagarEfectivo implements Pagable {

    @Override
    public void pagar(Float cantidad) {

    }

}
